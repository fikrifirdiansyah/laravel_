import { Dictionary } from './Dictionary';
export interface SpinnerOptions {
    enabled?: boolean;
    fillColor?: string;
    styles?: Dictionary;
}
